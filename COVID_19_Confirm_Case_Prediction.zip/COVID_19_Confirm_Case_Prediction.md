# IMPORT LIBRARY


```python
import sklearn
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import PolynomialFeatures
from sklearn import linear_model
```

# DATA LOAD


```python
#Data read using Pandas
data=pd.read_csv("D:\projects\Covid-19 outbreak prediction\COVID-19 Dataset\coronaCases.csv",sep=",")

data=data[['id','cases']] 
data.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>cases</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>229</th>
      <td>230</td>
      <td>21474437</td>
    </tr>
    <tr>
      <th>230</th>
      <td>231</td>
      <td>21706551</td>
    </tr>
    <tr>
      <th>231</th>
      <td>232</td>
      <td>21706551</td>
    </tr>
    <tr>
      <th>232</th>
      <td>233</td>
      <td>21901632</td>
    </tr>
    <tr>
      <th>233</th>
      <td>234</td>
      <td>22151281</td>
    </tr>
  </tbody>
</table>
</div>



# DATA PREPROCESSING


```python
x=np.array(data['id']).reshape(-1,1) #Data coversion to numpy array
y=np.array(data['cases']).reshape(-1,1)
plt.plot(y,'-m')
polyfeat=PolynomialFeatures(degree=4) # 4 degree polynomial
x=polyfeat.fit_transform(x)
plt.xlabel('X')
plt.ylabel('Y')
```




    Text(0, 0.5, 'Y')




![png](output_5_1.png)


# TRAINING DATA


```python
model=linear_model.LinearRegression()
model.fit(x,y)
accuracy=model.score(x,y) #Accuracy Calculation
print(f'Accuracy:{round(accuracy*100,3)}%')

Test=model.predict(x) #prediction
plt.plot(Test,'--b')
plt.xlabel('X')
plt.ylabel('Y')
plt.show()
```

    Accuracy:99.925%
    


![png](output_7_1.png)


# PREDICTION


```python
Days=3
print(f'Predicted Case after {Days} days:',end='')
print(round(int(model.predict(polyfeat.fit_transform([[234+Days]])))/1000000,3),'Million')
```

    Predicted Case after 3 days:23.596 Million
    

                            # Thanks


```python

```
